import os
import sys
import urllib.request
import json

def get_captcha_key():
    # 실제 발급받은 클라이언트 ID와 시크릿을 입력해야 합니다
    client_id = "실제_클라이언트_ID"  
    client_secret = "실제_클라이언트_시크릿"
    
    code = "0"  # 키 발급용 코드값
    
    url = "https://openapi.naver.com/v1/captcha/nkey"
    params = {"code": code}
    
    # URL에 파라미터 추가
    query_string = urllib.parse.urlencode(params)
    url = url + "?" + query_string

    # 요청 객체 생성
    request = urllib.request.Request(url)
    
    # 헤더 추가
    request.add_header("X-Naver-Client-Id", client_id)
    request.add_header("X-Naver-Client-Secret", client_secret)

    try:
        # API 호출
        with urllib.request.urlopen(request) as response:
            rescode = response.getcode()
            if rescode == 200:
                # 응답 읽기 및 디코딩
                response_body = response.read().decode('utf-8')
                # JSON 파싱
                result = json.loads(response_body)
                return result.get('key')  # 캡차 키 반환
            else:
                print(f"Error Code: {rescode}")
                return None
                
    except urllib.error.HTTPError as e:
        print(f"HTTP Error: {e.code}")
        print(f"Error Content: {e.read().decode('utf-8')}")
        return None
    except urllib.error.URLError as e:
        print(f"URL Error: {e.reason}")
        return None
    except Exception as e:
        print(f"Error: {str(e)}")
        return None

# 캡차 이미지 받기
def get_captcha_image(key):
    if not key:
        return None
        
    client_id = "실제_클라이언트_ID"
    client_secret = "실제_클라이언트_시크릿"
    
    url = f"https://openapi.naver.com/v1/captcha/ncaptcha.bin?key={key}"
    
    request = urllib.request.Request(url)
    request.add_header("X-Naver-Client-Id", client_id)
    request.add_header("X-Naver-Client-Secret", client_secret)
    
    try:
        with urllib.request.urlopen(request) as response:
            rescode = response.getcode()
            if rescode == 200:
                # 이미지를 파일로 저장
                filename = f"captcha_{key}.jpg"
                with open(filename, 'wb') as f:
                    f.write(response.read())
                return filename
            else:
                print(f"Error Code: {rescode}")
                return None
    except Exception as e:
        print(f"Error: {str(e)}")
        return None

def main():
    # 캡차 키 발급 받기
    key = get_captcha_key()
    if key:
        print(f"발급받은 캡차 키: {key}")
        
        # 캡차 이미지 받기
        image_file = get_captcha_image(key)
        if image_file:
            print(f"캡차 이미지가 저장됨: {image_file}")
        else:
            print("캡차 이미지 받기 실패")
    else:
        print("캡차 키 발급 실패")

if __name__ == "__main__":
    main()